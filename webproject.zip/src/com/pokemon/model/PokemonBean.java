package com.pokemon.model;

public class PokemonBean {
	private int PNO; 
	private String PNAME;
	private String PINITIAL;
	private String PTYPE;
	private String PTYPE2;
	private String PFEATURE;
	private String PFEATURE_H;
	private String PPICTURE;
	private String PHEIGHT;
	private String PWEIGHT;
	public int getPNO() {
		return PNO;
	}
	public void setPNO(int pNO) {
		this.PNO = pNO;
	}
	public String getPNAME() {
		return PNAME;
	}
	public void setPNAME(String pNAME) {
		this.PNAME = pNAME;
	}
	public String getPINITIAL() {
		return PINITIAL;
	}
	public void setPINITIAL(String pINITIAL) {
		this.PINITIAL = pINITIAL;
	}
	public String getPTYPE() {
		return PTYPE;
	}
	public void setPTYPE(String pTYPE) {
		this.PTYPE = pTYPE;
	}
	public String getPTYPE2() {
		return PTYPE2;
	}
	public void setPTYPE2(String pTYPE2) {
		this.PTYPE2 = pTYPE2;
	}
	public String getPFEATURE() {
		return PFEATURE;
	}
	public void setPFEATURE(String pFEATURE) {
		this.PFEATURE = pFEATURE;
	}
	public String getPFEATURE_H() {
		return PFEATURE_H;
	}
	public void setPFEATURE_H(String pFEATURE_H) {
		this.PFEATURE_H = pFEATURE_H;
	}
	public String getPPICTURE() {
		return PPICTURE;
	}
	public void setPPICTURE(String pPICTURE) {
		this.PPICTURE = pPICTURE;
	}
	public String getPHEIGHT() {
		return PHEIGHT;
	}
	public void setPHEIGHT(String pHEIGHT) {
		this.PHEIGHT = pHEIGHT;
	}
	public String getPWEIGHT() {
		return PWEIGHT;
	}
	public void setPWEIGHT(String pWEIGHT) {
		this.PWEIGHT = pWEIGHT;
	}
	
	
}
